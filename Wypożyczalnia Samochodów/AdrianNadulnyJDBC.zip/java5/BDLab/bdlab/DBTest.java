package bdlab;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

public class DBTest {
	public static class Lokalizacja {
		private int Id_lokalizacji;
		private String miasto;
		private String kod_pocztowy;

		@Override
		public String toString() {
			return "Lokalizacja [id=" + Id_lokalizacji + ", miasto=" + miasto + ", kod_pocztowy=" + kod_pocztowy + "]";
		}

		public int getId() {
			return Id_lokalizacji;
		}

		public void setId(int id) {
			this.Id_lokalizacji = id;
		}

		public String getMiasto() {
			return miasto;
		}

		public void setMiasto(String miasto) {
			this.miasto = miasto;
		}

		public String getKod_pocztowy() {
			return kod_pocztowy;
		}

		public void setKod_pocztowy(String kod_pocztowy) {
			this.kod_pocztowy = kod_pocztowy;
		}

		public Lokalizacja() {
		}

	}

	public final static ResultSetToBean<Lokalizacja> LokalizacjaConverter = new ResultSetToBean<Lokalizacja>() {
		public Lokalizacja convert(ResultSet rs) throws Exception {
			Lokalizacja e = new Lokalizacja();
			e.setId(rs.getInt("ID_LOKALIZACJI"));
			e.setMiasto(rs.getString("MIASTO"));
			e.setKod_pocztowy(rs.getString("KOD_POCZTOWY_LOK"));
			return e;
		}
	};

	public static void main(String[] args) {

		
		boolean result = DBManager.run(new Task<Boolean>() {
			public Boolean execute(PreparedStatement ps) throws Exception {
				ps.setString(1, "Opole");
				return ps.executeUpdate() > 0;
			}
		}, "update Lokalizacja set miasto = ? where Id_lokalizacji = 2 ");

		System.out.println(result ? "Udalo sie" : "Nie udalo sie");

		
		
		boolean insert_val = DBManager.run(new Task<Boolean>() {
			public Boolean execute(PreparedStatement ps) throws Exception {
				ps.setInt(1, 5);
				ps.setString(2, "Rzeszow");
				ps.setString(3, "09-321");
				return ps.executeUpdate() > 0;
			}
		}, "insert into Lokalizacja values(?,?,?)");

		System.out.println(insert_val ? "Udalo sie" : "Nie udalo sie");
		
		boolean insert_val1 = DBManager.run(new Task<Boolean>() {
			public Boolean execute(PreparedStatement ps) throws Exception {
				ps.setInt(1, 6);
				ps.setString(2, "Poznan");
				ps.setString(3, "09-211");
				return ps.executeUpdate() > 0;
			}
		}, "insert into Lokalizacja values(?,?,?)");

		System.out.println(insert_val1 ? "Udalo sie" : "Nie udalo sie");

		
		List<Lokalizacja> localization = DBManager.run(new Query() {
			public void prepareQuery(PreparedStatement ps) throws Exception {
				ps.setString(1, "Warszawa");
			}
		}, LokalizacjaConverter,
				"select Id_lokalizacji,Miasto,Kod_pocztowy_lok from Lokalizacja where miasto = ?");

		for (Lokalizacja e : localization) {
			System.out.println(e);
		}
		
		
		  boolean dele = DBManager.run(new Task<Boolean>() { 
		  public Boolean execute(PreparedStatement ps) throws Exception { 
		  ps.setString(1, "Rzeszow");
		  return ps.executeUpdate() > 0; } },
		  "delete from Lokalizacja where miasto = ?");
		  
		  System.out.println(dele ? "Udalo sie" : "Nie udalo sie");
		  
		 
	}

}
